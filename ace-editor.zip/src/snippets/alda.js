
;                (function() {
                    window.require(["ace/snippets/alda"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            